# 53 · 高端汽车广告视觉

- 分类：摄影或CG / 汽车广告
- 媒介：当次选择摄影或CG，默认摄影表达
- 类型：视觉预设
- 旧名称：高端汽车广告

## 核心特征

- 形态：曲率、比例和轮廓连续可读，构图服务结构特征。
- 材质：区分漆面、金属、玻璃和橡胶的反射与粗糙度。
- 光影：受控反射带和渐变解释曲面，外景光源与环境一致。
- 色彩：本色稳定，环境色辅助识别，不固定冷调。
- 空间：明确主次、干净遮挡和受控背景，暗棚、明棚及外景均可。

## 可调整项

按用户要求或参考确定摄影／CG；没有依据默认摄影表达并标注，不额外提问。棚拍／外景、明暗、冷暖、反射带、机位和动静均可调整。

## 不应自动加入

不自动加入品牌、车型、界面、道路、暗棚或广告文字；不修改既定比例与车身颜色。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Premium automotive visual treatment, readable sculpted forms, distinct paint, metal, glass and rubber responses, controlled reflection bands explaining curvature, coherent lighting and environment color, clean subject separation and precise visual hierarchy.

**中文：**高端汽车视觉表现，可读的雕塑般形体，可区分的漆面、金属、玻璃与橡胶响应，以受控反射光带解释曲率，连贯光照和环境色，干净主体分离与准确视觉层级。

## 使用边界

组合时只加入当次摄影或CG媒介开头，不堆两套设备或引擎；锚点描述可见结果，不证明实际执行拍摄或渲染。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
