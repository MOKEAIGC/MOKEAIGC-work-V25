# 12 · 东方仙侠写实

- 分类：写实 / 东方幻想
- 媒介：真人摄影与柔和幻想合成观感
- 类型：视觉预设
- 旧名称：东方仙侠

## 核心特征

- 形体与服饰有轻重对照，轻盈线条不消除身体和材料的体积。
- 自然形态与建筑/器物线条形成疏密节奏，既有东方形制保持连贯。
- 织物、木石、玉质或金属各有表面响应，不全部变成发光晶体。
- 光影过渡可柔和，主体轮廓和关键结构保持可读。
- 虚实层次、留白与尺度对照营造飘逸气质。

## 可调整项

- 青碧、淡紫、暖金为可选色彩关系，按角色、环境和情绪改变主色。
- 柔光、薄霭与局部辉光按场景使用；清晰日光或暗调也可保持轻盈形态。
- 超自然悬浮、灵气与特殊器物只表现已经成立的设定。

## 不应自动加入

- 默认浮山、云海、玉阁、全身光粒和神仙人物。
- 过量柔焦、塑料肤质、无结构意义的透明装饰。

## 风格锚点

EN：Photorealistic eastern-fantasy treatment, graceful continuous silhouettes with credible volume, differentiated tactile materials, balanced solid and open spaces, layered visual depth, gentle but readable light transitions, controlled luminous accents where the established setting supports them.

中文：东方幻想摄影写实，优雅连贯且体积可信的轮廓，清晰区分的可触材料，平衡的实体与留白，分层空间纵深，柔和但可读的光影过渡，仅在既定设定支持时使用受控发光点缀。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

轻盈与写实可以并存；不要以全画面光晕代替材质和造型。用户要求非写实仙侠时应覆盖媒介，不暗中混入2D或3D。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
