# 54 · 魔法世界电影写实（哈利波特参考）

- 分类：电影写实 / 古典魔法题材
- 媒介：真人电影感写实表达
- 类型：视觉预设
- 旧名称：魔法世界（哈利波特）

## 核心特征

- 形态：历史积累感的比例、结构与装饰层级，主体服从用户世界。
- 材质：区分石、木、纸、织物与金属，旧化由使用位置决定。
- 光影：局部光源与环境补光形成层次，魔法光只在设定存在时加入。
- 色彩：材料本色与光源色分离，暖褐、深绿、金色均为可选关系。
- 空间：遮挡、尺度和光区递进形成可探索感，不依赖固定建筑。

## 可调整项

时代、环境、日夜、旧化、装饰密度与魔法光强度可变；暖烛光仅为子方案。

## 不应自动加入

不自动加入学院、浮烛、长袍、魔杖、城堡、咒语或原作角色。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Material-rich live-action fantasy cinematography, historically layered forms, tactile differentiated surfaces, motivated pools of light and coherent ambient fill, controlled material-color and illumination relationships, layered depth and discoverable space.

**中文：**材质丰富的真人奇幻电影摄影感，具有历史层次的形体，可触且区分明确的表面，有动机的局部光区和连贯环境补光，受控的材质色与照明关系，层叠纵深和可探索空间。

## 使用边界

哈利波特仅为检索参考名，不复制作品设定；没有可见魔法时仍通过材质、光区和空间保持风格。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
