# 17 · 超自然灵异恐怖写实

- 分类：写实 / 超自然恐怖
- 媒介：真人摄影与克制异常合成观感
- 类型：视觉预设
- 旧名称：超自然&灵异恐怖（美式恐怖）

## 核心特征

- 负空间、门洞、遮挡和边缘可见区域共同控制未知威胁。
- 现实材质和空间尺度维持可信基底，使局部异常具有重量。
- 明暗关系引导观看顺序，而非简单把整张画面压暗。
- 轮廓、反射或对称关系的轻微偏差可制造不安。
- 可见超自然效果数量受控，保留未揭示的信息。

## 可调整项

- 冷青灰、幽蓝、死白是可选冷调子型，不排除暖光室内或明亮场景。
- 清晰与柔化、稳定与失衡、空旷与幽闭可按威胁方式选择。
- 显形程度服从情节；未知、影子与实体怪物不能互相自动替代。

## 不应自动加入

- 默认鬼屋、浓雾、白色幽灵、发光眼睛。
- 将有意未知的威胁具象化，或把所有人物变成受惊尖叫姿态。

## 风格锚点

EN：Photorealistic supernatural-horror treatment, credible everyday materials and scale, deliberate negative space and selective occlusion, readable light-dark hierarchy, restrained disturbances in contour or reflection, tension sustained by what remains outside clear view.

中文：超自然恐怖摄影写实，可信的日常材料与尺度，有意组织的负空间和选择性遮挡，可读的明暗层级，轮廓或反射中的克制扰动，由未进入清晰视野的部分持续维持张力。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

原名称中的“美式”只表示参考范围，不要求自动增加特定国家建筑或家庭设定。恐怖感应适应已有空间。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
