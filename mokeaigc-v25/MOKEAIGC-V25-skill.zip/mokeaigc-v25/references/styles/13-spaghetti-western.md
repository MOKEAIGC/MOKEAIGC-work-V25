# 13 · 意式西部写实

- 分类：写实 / 意式西部
- 媒介：真人摄影与粗粝胶片观感
- 类型：视觉预设
- 旧名称：经典西部牛仔

## 核心特征

- 极端距离对照建立紧张感，特写与大全景通常分配到不同画面。
- 面部、衣物与物件的边缘和磨损能承受近距离观察。
- 方向明确的硬光与阴影形成强形体对比，光源由场景决定。
- 空间留白、遮挡与视线方向延长等待和对峙感。
- 材料保留粗粝而有差异的表面，颗粒不掩盖结构。

## 可调整项

- 焦黄、铁锈红、暗褐为可选灼热色板；夜景、阴天或室内按实际环境调整。
- 安静凝滞、紧绷动作与宏观尺度交替使用，用户只要单帧时选择一个明确主构图。
- 光学旧化、颗粒与对比程度按需求控制，不必强制使用变形镜头光效。

## 不应自动加入

- 默认沙漠、牛仔、枪械、决斗或正午太阳。
- 把极端特写与广角并置误写成同一张分屏、拼贴或两套透视。

## 风格锚点

EN：Photographic spaghetti-western treatment, tactile roughness and legible wear, strong directional modeling, tense spatial pauses and deliberate sightlines, deliberate scale and viewing distance within a single coherent framing, restrained film-like texture with clear physical detail.

中文：意式西部摄影表现，可触的粗粝感与可读磨损，方向明确的强体积塑造，紧张的空间停顿与有意组织的视线，在单一连贯构图中有意选择尺度与观看距离，克制胶片肌理下保留清楚的物理细节。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

此卡明确为意式西部子预设，不代表全部西部电影。单张完整提示词只指定一种主镜头/透视；多镜头的景别对照写在组间规划中。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
