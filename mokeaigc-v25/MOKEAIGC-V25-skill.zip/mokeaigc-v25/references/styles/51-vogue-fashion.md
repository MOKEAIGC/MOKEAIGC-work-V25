# 51 · 时尚编辑摄影（Vogue参考）

- 分类：摄影 / 时尚编辑
- 媒介：受控摄影表达，影棚或实景均可
- 类型：视觉预设
- 旧名称：Vogue杂志

## 核心特征

- 形态：姿态、服装轮廓和裁切形成有目的的线条关系，身份不被统一模特化。
- 材质：区分织物、皮革、金属与皮肤，精修不抹掉结构。
- 光影：按塑形目标配置主光、轮廓光和反射光，可柔可硬。
- 色彩：围绕造型主题选择克制或鲜明的色组。
- 空间：允许摆姿、居中、留白、近裁切与受控场景，姿态必须可读。

## 可调整项

影棚／实景、光质、色调、焦距、服装密度、姿态和裁切可变，不固定80mm或冷艳情绪。

## 不应自动加入

不自动加入杂志字样、商标、品牌、摄影师署名、明星身份或特定服装；不把Vogue全刊视为统一画风。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Fashion editorial photography, intentional styling silhouettes and posing, precise material separation, controlled light shaping, deliberate figure-setting color relationships, purposeful cropping and negative space, polished detail with readable structure.

**中文：**时尚编辑摄影，有目的的造型轮廓与姿态，准确材质区分，受控光照塑形，人物与环境间明确的色彩关系，有目的的裁切和留白，精致细节中保留清楚结构。

## 使用边界

Vogue仅为检索参考；模式A需传达世界信息，但不得仅因默认生活剧照规则取消时装造型或受控摆姿。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
