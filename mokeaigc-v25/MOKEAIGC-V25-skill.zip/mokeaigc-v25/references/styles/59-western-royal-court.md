# 59 · 西方宫廷年代电影写实

- 分类：电影写实 / 历史宫廷题材
- 媒介：依既定时代组织的真人年代电影表达
- 类型：视觉预设
- 旧名称：西方宫廷

## 核心特征

- 形态：建筑比例、服装剪裁和器物轮廓属于同一时代地区，不跨时代拼贴。
- 材质：织造、金属工艺、木石与装饰尺度相容，富丽程度按阶层场所变化。
- 光影：窗光、烛光或时代允许的光源有明确方向。
- 色彩：服装、室内和光源形成受控色组，不机械套金红。
- 空间：比例、门槛、距离、遮挡和对称关系表现秩序，不每帧大殿。

## 可调整项

继承已有年代、国家或参考后决定材料剪裁。未给时采用明确标注的虚构宫廷方案，不声称考据；要求真实还原且时代缺失时才询问。

## 不应自动加入

不自动加入王冠、珠宝、华服、特定王室或跨作品设计；现代宫廷不自动穿古装。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Period-coherent court cinematography, consistent architectural proportions and costume construction, differentiated craft materials, motivated illumination, coordinated environment and wardrobe colors, deliberate spatial hierarchy and controlled ornament.

**中文：**时代一致的宫廷电影摄影感，相容的建筑比例与服装结构，可区分的工艺材料，有动机的照明，协调的环境与服装颜色，有目的的空间层级和受控装饰。

## 使用边界

宫廷是题材，不指定通用豪华外观。未知时代不由多个作品名拼装；真实历史细节只在世界允许时加入。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
