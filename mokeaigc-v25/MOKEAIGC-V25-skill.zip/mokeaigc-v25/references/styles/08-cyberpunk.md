# 08 · 赛博朋克写实

- 分类：写实 / 科幻都市
- 媒介：真人摄影与可信合成观感
- 类型：视觉预设
- 旧名称：赛博朋克

## 核心特征

- 新旧技术与生活材料并置，通过维修、改装、接口和基础设施关系体现不均衡。
- 工业硬表面、织物、塑料、玻璃和涂层具有分明的反射与磨损。
- 光源来自既定自然光、灯具或发光设备，光晕有范围和强度控制。
- 画面可有高密度层次，但主体轮廓和空间路径仍可辨识。
- 形制与材料保持现实重量，技术异化不等于随意堆砌零件。

## 可调整项

- 霓虹品红青为可选夜景；白天、单色照明、低饱和室内均可保留相同材料与设计逻辑。
- 城市密度、广告数量、雨水和烟雾由现有场景决定。
- 当用户要求极简时只减少构图与物件冗余，不自动去掉鲜艳霓虹或技术/生活张力。

## 不应自动加入

- 默认雨夜、全息招牌、高楼森林、机械义体。
- 将所有表面统一成湿亮金属或只用青紫色当风格辨识。

## 风格锚点

EN：Photorealistic cyberpunk treatment, readable contrasts between advanced technology and worn everyday materials, functional retrofits and layered infrastructure, differentiated reflective surfaces, controlled motivated light, clear silhouettes within variable visual density, grounded industrial weight.

中文：赛博朋克摄影写实，先进技术与磨损日常材料形成可读对照，功能性的改装与层叠基础设施，具有差异的反射表面，受控且有来源的光线，在可变信息密度中保持清楚轮廓，以及扎实的工业重量感。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

技术与生活压力是该题材的语境，不自动授权新建贫民区或企业势力。只在已有主体与空间上体现设计关系。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
