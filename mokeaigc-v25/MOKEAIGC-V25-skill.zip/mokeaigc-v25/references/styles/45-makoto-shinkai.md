# 45 · 通透光色日系动画（精细背景）

- 分类：2D / 日系动画
- 媒介：二维绘制，精细背景与简洁主体造型
- 类型：视觉预设
- 旧名称：新海诚（主流国漫风格）

## 核心特征

- 形态：主体轮廓简洁，背景结构可信，形成细节密度对比。
- 线条与材质：稳定线稿与分层绘景并存，表面纹理有主次。
- 光影：光源方向、遮挡与反射清楚，高光通透但不覆盖轮廓。
- 色彩：以环境色、局部色和光源色的关系组织情绪，不统一高饱和。
- 空间：用层叠、空气透视和选择性细节组织焦点。

## 可调整项

时间、天气、饱和度、背景密度和景别可变；天空、耀斑、丁达尔光依实际光照条件使用，青春与忧伤只是可选情绪。

## 不应自动加入

不自动加入城市、天空、学生、爱情或作者署名；不再称为“主流国漫”。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Detailed-background 2D animation, clean controlled contours, restrained subject shading, richly observed environmental surfaces, coherent directional light and reflections, luminous highlight gradation, purposeful warm-cool relationships and layered depth.

**中文：**精细背景二维动画，干净受控的轮廓，简洁的主体明暗，细致观察的环境表面，连贯的方向光与反射，通透高光层次，有目的的冷暖关系和层叠纵深。

## 使用边界

旧名称中的作者名只作检索参考，不代表其全部作品；无天空、无耀斑的场景仍通过线条、背景密度和光色关系保持风格。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
