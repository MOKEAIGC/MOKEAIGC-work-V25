# 28 · 中式暗黑神魔写实CG

- 分类：3D / 东方暗黑奇幻视觉预设
- 媒介：写实3D CG
- 类型：视觉预设
- 旧名称：手游unity

## 核心特征

- 造型重视体块的重量、比例与层叠轮廓，东方装饰在构造成立后发挥作用。
- 青铜、漆面、岩石、皮革、丝织物等以各自粗糙度、纹理与反射区分。
- 明暗对照强调形体威严，亮区控制在必要焦点，不让全画面同时发光。
- 暗色基底可搭配朱红、青黛或金色，但配色取决于既定对象与文化。
- 空间通过尺度参照、遮挡和明暗层次建立，细节密度有主次。

## 可调整项

- 装饰密度、做旧量、饱和度、雾感和光线硬度可调整。
- 中式元素只用于用户已允许的文化与设计范围。
- 实际游戏引擎与平台性能要求单独处理。

## 不应自动加入

- 自动增加神佛、妖魔、古寺、山崖、祥云或佛光。
- 把“Unity手游”或“虚幻引擎级”作为本卡风格标签。
- 为追求威严而无限堆叠金饰、发光符文和复杂材质。

## 风格锚点

**EN：** Eastern dark-fantasy realistic 3D imagery with weighty layered forms, structurally integrated ornament, distinct bronze, lacquer, stone and fabric responses, strong but selective light-dark separation, controlled dark color relationships and clear scale hierarchy.

**中文：** 东方暗黑奇幻写实3D画面，形体厚重并具有层叠关系，装饰与结构结合，青铜、漆面、石材和织物的响应各不相同，明暗分离强烈但有所取舍，暗色关系受控，尺度层级清楚。

## 使用边界

- 旧名称“手游unity”与原内容不符，现按实际视觉内容命名。该卡不意味着移动端资产规范，也不声称使用任何渲染引擎。

风格锚点用于与当前主体、动作、环境及构图组合，不是完整出图提示词。执行模式、用户覆盖项与平台格式见 [V25主入口](../../SKILL.md)。
