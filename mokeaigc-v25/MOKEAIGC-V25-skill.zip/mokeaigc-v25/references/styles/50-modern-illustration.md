# 50 · 现代数字编辑插画

- 分类：2D / 编辑与商业插画
- 媒介：二维数字插画，平面图形组织为主
- 类型：视觉预设
- 旧名称：插画

## 核心特征

- 形态：概括轮廓与清楚几何关系服务信息层级。
- 线条：可用简洁线稿或色块边缘，整图保持一致。
- 材质：平涂为主，局部渐变或少量纹理区分表面。
- 光影：有限明暗层次，立体塑形不压过平面设计。
- 空间与色彩：协调色组、正负形和留白组织焦点，允许压缩透视。

## 可调整项

色数、抽象程度、线稿有无、渐变、纹理密度和空间平面化程度可变。

## 不应自动加入

不自动加入文案、品牌、文字排版、时尚人物或画家署名；不把所有插画都解释成此卡。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Contemporary digital editorial illustration, simplified purposeful shapes, consistent contour or color-edge language, predominantly flat colors with selective soft gradients, limited value planes, coordinated colors, deliberate negative space and clear graphic hierarchy.

**中文：**现代数字编辑插画，简化而有目的的形状，一致的轮廓或色块边缘语言，以平涂为主并局部使用柔渐变，有限明暗块面，协调颜色，有意识的留白和清楚图形层级。

## 使用边界

不涵盖水彩、写实油画等所有插画媒介；平面图说明空间组织即可，不强塞焦距和浅景深。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
