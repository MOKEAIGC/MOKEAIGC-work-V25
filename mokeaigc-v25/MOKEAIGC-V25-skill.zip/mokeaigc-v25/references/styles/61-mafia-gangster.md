# 61 · 黑帮犯罪电影写实

- 分类：电影写实 / 黑帮犯罪题材
- 媒介：真人犯罪电影表达
- 类型：视觉预设
- 旧名称：黑帮

## 核心特征

- 形态：人物、服装和环境比例可信，年代地域由世界决定。
- 材质：织物、皮革、玻璃、木石有清楚差异，精致粗粝按场景选择。
- 光影：选择性明暗和有动机的局部光控制信息，不等于看不清。
- 色彩：受控配色保留本色，暖棕复古只是子方案。
- 空间：距离、席位、视线、门框与遮挡组织权力关系。

## 可调整项

时代、文化、明暗、冷暖、华丽程度和距离可变；用户未设黑帮时只借光影空间语言。

## 不应自动加入

不自动加入西装、雪茄、威士忌、枪械、教父、密室或复古年代；不以画风添加犯罪事实。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Controlled live-action crime cinematography, credible forms and differentiated materials, selective motivated illumination, restrained color relationships, purposeful framing and concealment, spatial arrangements conveying tension and relative power.

**中文：**受控真人犯罪电影摄影感，可信形体与可区分材质，选择性且有动机的照明，克制色彩关系，有目的的取景和遮蔽，传达张力与相对权力的空间安排。

## 使用边界

暖棕低光不代表所有黑帮题材；普通生活画面保留这套光影和空间组织，不强行成为犯罪现场。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
