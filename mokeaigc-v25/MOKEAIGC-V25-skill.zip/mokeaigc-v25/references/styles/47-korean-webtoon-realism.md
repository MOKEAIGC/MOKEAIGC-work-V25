# 47 · 韩漫写实硬派风

- 分类：2D / 韩式网漫
- 媒介：二维硬派网漫绘制
- 类型：视觉预设
- 旧名称：韩漫写实硬派风

## 核心特征

- 形态：骨骼、肌肉、重心和重量关系扎实，不把所有人变成健美体型。
- 线条：轮廓有轻重，结构线集中于受力与转折。
- 材质：数字笔触和图形化明暗保留表面差异。
- 光影：硬边阴影与方向明确的亮面塑形，对比有主次。
- 空间：重叠剪影、透视和重心组织张力，平静场景仍保持结构力度。

## 可调整项

冷暖、明暗比例、线粗、背景密度和动作强度可变；速度线只在动作表达需要时加入。

## 不应自动加入

不自动加入打斗、血迹、夸张肌肉或逆袭剧情；日常场景不变成战斗。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Hard-edged 2D webtoon rendering, grounded forms, weighted contours and selective anatomical detail, directional hard-shadow planes, controlled contrast, distinct digital surfaces, forceful silhouettes and readable spatial overlaps.

**中文：**硬朗二维网漫表现，扎实形体，有力度的轮廓与选择性解剖细节，有方向的硬边阴影，受控反差，可区分的数字表面，有力剪影与清楚空间重叠。

## 使用边界

写实指形体可信度，媒介仍为二维；不恢复真人皮肤、摄影机或胶片固定串。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
