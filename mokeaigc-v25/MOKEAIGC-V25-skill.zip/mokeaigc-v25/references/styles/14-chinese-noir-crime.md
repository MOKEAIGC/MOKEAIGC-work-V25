# 14 · 中式警匪·黑色电影

- 分类：写实 / 犯罪悬疑
- 媒介：真人摄影与黑色电影明暗观感
- 类型：视觉预设
- 旧名称：中式警匪

## 核心特征

- 低调明暗与有方向的阴影划分人物及空间，暗部仍保留关键信息。
- 门框、遮挡、倒影和几何切分表达观察、隔离或权力关系。
- 硬边光与中间调共同塑造材质，不把所有表面压成纯黑白。
- 布料、玻璃、旧漆和金属保持现实质感，烟雾只在有依据时存在。
- 地域特征由已给建筑、服饰、器物与生活细节体现，不由“中国”标签代替。

## 可调整项

- 默认可为低饱和或受控彩色noir；只有用户明确选黑白时移除色彩。
- 高反差强度、硬光比例、暗角和颗粒按环境与可读性调整。
- 城市、年代、犯罪线索和人物身份均由本次内容决定。

## 不应自动加入

- 默认百叶窗、烟雾审讯室、雨夜小巷。
- 将所有中式警匪都改成复古黑白，或默认侦探/黑帮人物。

## 风格锚点

EN：Photorealistic Chinese crime-noir treatment, motivated low-key illumination and deliberate shadow geometry, restrained color or explicitly selected monochrome, tactile everyday materials, layered occlusion and reflections, framing that makes distance, observation and power relationships legible.

中文：中式犯罪黑色电影写实，有来源的低调光照与有意组织的阴影几何，克制色彩或明确选定的黑白，可触的日常材料，层叠遮挡与倒影，以及让距离、观察和权力关系清晰可读的构图。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

此卡是中式警匪中的黑色电影子型；若用户要求日光纪实警匪，不强制套用低调noir。黑色电影的“黑”不等于必须黑白成像。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
