# 09 · 废土末世写实

- 分类：写实 / 末世
- 媒介：真人摄影观感
- 类型：视觉预设
- 旧名称：废土

## 核心特征

- 老化、拆用、补缀与维修痕迹能追溯材料用途与使用环境。
- 原有结构与后来加装的部件形成可辨认的时间层次。
- 布料、木石、金属、玻璃等保留不同损坏方式，不能统一覆盖同一锈色。
- 残缺与留空传达功能退化和空间尺度，细节集中在叙事需要处。
- 照明、沉积、潮湿和植被痕迹符合所在气候。

## 可调整项

- 荒漠可使用沙尘和暖褐色；寒地使用冻融/积雪；潮湿区域使用水渍、腐蚀或植被侵入，按世界条件选择。
- 破坏程度、修复水平与物资紧缺程度可调，不把所有对象做成完全报废。
- 自然光和实用光均可使用，温度与颜色来自场景而非固定末日滤镜。

## 不应自动加入

- 默认沙漠、烈日、沙暴、孤独人物。
- 无差别铁锈、全身泥污、无结构意义的废料堆。

## 风格锚点

EN：Photorealistic post-collapse treatment, material-specific aging and functional repair, visible layers of original construction and later reuse, credible structural wear, readable scale and absence, environmental deposits and illumination consistent with the established climate.

中文：崩塌后世界的摄影写实，符合材料特性的老化与功能性修复，可辨认的原始构造和后期再利用层次，可信的结构磨损，可读的尺度与缺失，环境沉积和光照符合既定气候。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

先保持原世界的气候与资源条件，再决定磨损和修补形式；废土不是沙漠的同义词。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
