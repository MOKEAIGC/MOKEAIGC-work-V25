# 65 · 纪实感犯罪悬疑电影

- 分类：电影写实 / 犯罪悬疑
- 媒介：克制可信的真人电影表达
- 类型：视觉预设
- 旧名称：真实犯罪/悬疑惊悚

## 核心特征

- 形态：人物、物件和环境有可信比例，细节由功能决定。
- 材质：自然表面差异和合理使用痕迹，不为压抑统一加脏。
- 光影：有动机的照明保持观察可信度，悬念来自信息分配而非必须低光。
- 色彩：克制调色保留有效色差，冷灰蓝与钠灯黄只是方案。
- 空间：视线、遮挡、留白和景别控制已知信息，细节具有具体作用。

## 可调整项

日夜、暖冷、饱和度、光源、机位和信息暴露可变；案发现场、审讯和警探视角只在故事需要时采用。

## 不应自动加入

不自动加入警探、罪犯、证据、案件、沉郁表情或真实人物指控；纪实感不等于事实认证。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Restrained observational crime-thriller cinematography, credible proportions and material detail, motivated lighting, controlled grading, purposeful sightlines and concealment, measured negative space and a clear hierarchy of visual information.

**中文：**克制观察式犯罪惊悚电影摄影感，可信比例和材质细节，有动机的照明，受控调色，有目的的视线与遮蔽，适度留白和清楚视觉信息层级。

## 使用边界

本卡不核验案件，也不让虚构故事变成事实；用户没有要求真实题材时不添加真实性主张。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
