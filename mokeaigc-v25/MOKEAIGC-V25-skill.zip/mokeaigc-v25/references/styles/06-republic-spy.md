# 06 · 民国谍战（彩色年代正剧）

- 分类：写实 / 年代悬疑
- 媒介：彩色真人摄影观感
- 类型：视觉预设
- 旧名称：民国-谍战风云

## 核心特征

- 保留彩色中间调，暖琥珀、青灰和旧褐可形成怀旧层次但不压成单一棕色。
- 服装织物、木漆、玻璃和金属各有表面响应与适度使用痕迹。
- 窗光与室内实用光形成有来源的明暗分区，暗部仍保留颜色。
- 门框、遮挡、反射与人物间距表达信息差和观察关系。
- 建筑、服装和器物细节遵循既定年代与地区。

## 可调整项

- 暖色或冷色的比例跟随场景光源；可用局部硬窗光，也可用柔和室内光。
- 年代颗粒、褪色程度与反差按需求调整，保留彩色摄影基底。
- 城市、乡村、室内外与具体年份依据用户内容选择。

## 不应自动加入

- 默认黑白、monochrome或经典film noir整体处理。
- 默认上海、旗袍、风衣、香烟等叙事物件。

## 风格锚点

EN：Color period-drama realism, preserved chromatic midtones and colored shadows, restrained warm-cool relationships, tactile period materials, motivated window and practical light, layered occlusion and reflective framing that support quiet suspense, subtle aged-film color response.

中文：彩色年代正剧写实，保留有色中间调和暗部颜色，克制的冷暖关系，可触的年代材料，有来源的窗光与实用光，通过层层遮挡和反射构图支撑安静的悬念，带有轻微旧胶片色彩响应。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

“暗调谍战”不自动等于黑白noir。本卡默认彩色；用户明确要求黑白时应标明覆盖了本卡的彩色预设。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
