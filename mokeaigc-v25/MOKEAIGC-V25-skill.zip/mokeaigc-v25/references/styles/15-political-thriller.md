# 15 · 政治／谍战惊悚（西方）

- 分类：写实 / 政治悬疑
- 媒介：真人摄影观感
- 类型：视觉预设
- 旧名称：政治 / 谍战惊悚（西方）

## 核心特征

- 空间秩序、人物距离与遮挡承载层级和信息不对称。
- 构图稳定而有约束，留白与重复线条形成压力。
- 光线由环境来源解释，暗部保留能让观众推断关系的线索。
- 材料、服装和建筑保留现实比例与受控细节，不靠科技装饰制造专业感。
- 表情和姿态克制，紧张感可来自静止与局部动作。

## 可调整项

- 冷青灰是可选色调；温暖但压抑的室内同样成立。
- 低调程度、焦点隔离和空间压缩按信息表达选择。
- 地域、年代、机构与政治关系遵循已有内容。

## 不应自动加入

- 默认政府走廊、秘密会议、武器或监控设备。
- 统一冷蓝滤镜、无依据的西方国家符号或特定机构标志。

## 风格锚点

EN：Photorealistic political-thriller treatment, controlled spatial order and meaningful interpersonal distance, stable framing with selective occlusion, restrained gestures, motivated light and readable shadow information, credible contemporary or established-period materials, pressure built through visual hierarchy.

中文：政治惊悚摄影写实，受控的空间秩序与有意义的人物间距，稳定构图中的选择性遮挡，克制姿态，有来源的光线与可读暗部信息，可信的当代或既定年代材料，通过视觉层级建立压力。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

用关系与信息组织表达惊悚，不把人物职业、机构或国家立场从风格名自动补入世界。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
