# 56 · 哥特吸血鬼电影写实

- 分类：电影写实 / 哥特浪漫
- 媒介：真人电影感哥特视觉
- 类型：视觉预设
- 旧名称：吸血鬼

## 核心特征

- 形态：修长轮廓、重复节奏与有重量的实体，不强制特定建筑服装。
- 材质：粗糙与光洁、吸光与反光对照，精致可与旧化共存。
- 光影：局部照明与深暗区域选择性揭示，暗部保留必要体积。
- 色彩：深色基底配少量浓色强调，肤色沿用角色设定。
- 空间：亲密距离、压缩或遮挡组织情绪张力，不限室内。

## 可调整项

浪漫／恐怖比重、装饰密度、亮暗、时代与环境可变；酒红、烛光、丝绒均为选项。

## 不应自动加入

不自动加入尖牙、血液、贵族、苍白美人、情欲或豪宅；非吸血鬼主体不改物种。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Gothic live-action visual treatment, elongated rhythmic forms, contrasting absorbent and reflective surfaces, selective light against structured darkness, a deep restrained palette with concentrated accents, layered concealment and intimate spatial tension.

**中文：**哥特真人电影视觉，修长而有节奏的形体，吸光与反光表面对照，结构清楚的暗部中选择性光照，深沉克制配色与集中强调色，层叠遮蔽和亲密空间张力。

## 使用边界

本卡为哥特分支，不代表所有吸血鬼表达；物种特征、危险程度与情感关系由用户世界决定。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
