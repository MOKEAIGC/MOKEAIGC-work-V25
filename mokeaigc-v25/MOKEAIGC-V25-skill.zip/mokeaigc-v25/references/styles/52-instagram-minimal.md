# 52 · 柔光低饱和极简生活方式摄影

- 分类：摄影 / 极简生活方式
- 媒介：简洁自然光摄影表达
- 类型：视觉预设
- 旧名称：Ins极简风

## 核心特征

- 形态：少量清楚形状和比例关系组织画面，减少无关小轮廓。
- 材质：表面真实可区分，干净不等于无纹理塑料。
- 光影：柔漫射光保留接触阴影和基本体积。
- 色彩：低饱和协调色组为主，少量重点色建立焦点。
- 空间：留白、间距与稳定结构保持可读性。

## 可调整项

暖冷、主体颜色、背景明度、留白比例和物件数量可变；奶白、燕麦、浅灰、雾蓝仅为示例。

## 不应自动加入

不自动加入北欧家居、咖啡、花瓶、网红摆件或平台界面；极简不能删掉用户必要内容。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Soft-light minimalist lifestyle photography, few clear forms, distinct natural surfaces, gentle diffuse illumination with contact shadows, a restrained low-saturation palette, purposeful breathing space and stable visual hierarchy.

**中文：**柔光极简生活方式摄影，少量清楚形状，可区分自然表面，带接触阴影的柔漫射光，克制低饱和配色，有目的的呼吸留白与稳定视觉层级。

## 使用边界

旧称Ins极简风不代表整个社交平台。用户覆盖为硬光或高饱和时记录覆盖，不以默认词抵消。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
