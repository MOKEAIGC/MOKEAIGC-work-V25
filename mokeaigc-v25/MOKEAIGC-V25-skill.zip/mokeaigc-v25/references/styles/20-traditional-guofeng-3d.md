# 20 · 传统国风3D

- 分类：3D / 国风
- 媒介：具有立体体积的风格化三维动画
- 类型：视觉预设
- 旧名称：传统国风3D

## 核心特征

- 人物、衣物与物件具有明确的立体体积和结构衔接。
- 轮廓、衣饰线条与建筑形制沿用既定东方文化语境。
- 材质可概括但保持区分，金属、织物、石木不共享一层塑料光泽。
- 光照以清晰体块、轮廓和受控反射塑形，虚实不消除三维结构。
- 留白与线条疏密组织空间，形体比例保持跨图稳定。

## 可调整项

- 建模简化程度、表面细节与卡通比例可按目标调整，不因“传统”而强制模仿早期技术局限。
- 青灰、玄黑、暗金只是一个古朴子色板，允许明亮、鲜艳或轻淡方案。
- 写意山水、古风建筑与服饰纹样只有在内容已有时出现；场景也可转为普通日常空间。

## 不应自动加入

- 默认早期低精度模型、僵硬表情、低体积光照。
- 把所有表面改为2D水墨、真人照片皮肤或同一种柔滑材质。

## 风格锚点

EN：Stylized three-dimensional guofeng animation, readable volumes and coherent construction, culturally grounded silhouettes and flowing line rhythms, differentiated simplified materials, clear form-revealing light and controlled reflections, balanced solid and open space, stable proportions across images.

中文：风格化国风三维动画，可读的体积与连贯构造，有文化形制依据的轮廓和流动线条节奏，区分明确的概括材料，清楚塑造体块的光线与受控反射，平衡的实体和留白，跨图稳定的比例。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

“传统”指文化形制和表达，不等同于旧技术画质。与水墨2D的区别是保留体积、材质受光与空间结构。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
