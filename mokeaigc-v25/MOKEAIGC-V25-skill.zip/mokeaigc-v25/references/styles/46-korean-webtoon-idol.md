# 46 · 韩漫唯美偶像风

- 分类：2D / 韩式网漫
- 媒介：二维线稿与平滑数字上色
- 类型：视觉预设
- 旧名称：韩漫唯美偶像风

## 核心特征

- 形态：清楚修长的比例与简洁面部平面，既有身份特征保持。
- 线条：纤细稳定，选择性强调五官、衣褶和动作。
- 材质：平滑数字上色配局部水润高光，不使用实体油彩堆积。
- 光影：柔和过渡保留轮廓与结构，柔焦不吞没线条。
- 色彩与空间：协调色组、清楚的人物背景分离与有主次的焦点。

## 可调整项

色相、光源、背景密度、景别与情绪可变；奶粉、浅紫、薄荷和暖白是示例配色。

## 不应自动加入

不自动加入偶像职业、爱情、统一白肤色或同一张美型脸；不磨平年龄与表情。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Refined 2D webtoon rendering, delicate controlled linework, elegant readable proportions, smooth digital color transitions, selective dewy highlights, soft light preserving structure, coordinated colors and clear figure-background separation.

**中文：**精致二维网漫表现，纤细受控线条，优雅清楚的比例，平滑数字色彩过渡，选择性水润高光，保留结构的柔光，协调颜色与明确人物背景分离。

## 使用边界

数字厚涂指上色方式，不要求厚油彩肌理；世界概览可使用同一线条与上色体系描绘环境，不必全部成为肖像。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
