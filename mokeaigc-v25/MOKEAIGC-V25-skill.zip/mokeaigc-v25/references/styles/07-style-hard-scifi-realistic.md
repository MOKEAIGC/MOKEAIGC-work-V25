# 07 · 硬科幻（纪实写实）

- 分类：写实 / 硬科幻
- 媒介：真人纪实摄影观感
- 类型：视觉预设
- 旧名称：硬科幻（纪实写实）

## 核心特征

- 结构、接缝、连接件与材料分工能由既定工程功能解释。
- 身体与物件的支撑、漂浮或下落服从当前重力条件。
- 照明、反射与散射由光源、介质和表面共同决定。
- 空间尺度可读，细节密度服从功能而非装饰性科技符号。
- 表面和成像保持可信，不用过量炫光替代工程结构。

## 可调整项

- 真空外部：仅在成立时使用太阳硬光和具体天体/设备反照；没有介质时不添加空中光束或雾。
- 有大气地表：按空气、尘埃、云层与实际天体调整散射、天空光及阴影；不沿用真空光照。
- 舱内：以灯具、屏幕、舷窗及表面反射组织光；失重仅在世界和场景支持时启用。
- 颗粒、反差与观测视角可调，画幅观感与颗粒程度分别控制。

## 不应自动加入

- 默认近地轨道、NASA标识、宇航服、地球反照或失重。
- 无依据的星云、神性光束、魔法光环和满屏装饰性界面。

## 风格锚点

EN：Documentary-style photorealistic hard science fiction, function-led construction and material separation, credible scale and mechanical interfaces, motion and support consistent with the established gravity, illumination and scattering consistent with the local medium, restrained optical effects and readable engineering detail.

中文：纪实摄影式硬科幻写实，以功能驱动构造和材料分工，可信的尺度与机械连接，运动和支撑符合既定重力，照明与散射符合所在介质，克制的光学效果和可读的工程细节。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

先确定真空、地表或舱内，再写光线和运动状态。技术可信性由具体结构支撑，不用机构名称或“精确硬件”空泛标签作保证。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
