# 10 · 中世纪史诗写实

- 分类：写实 / 历史史诗
- 媒介：真人摄影观感
- 类型：视觉预设
- 旧名称：中世纪史诗

## 核心特征

- 建筑、器物与身体之间的尺度差建立厚重感，而不只靠低角度标签。
- 石、木、锻造金属、皮革和织物保持各自结构、接合和受力方式。
- 自然天光及已有室内光源塑造体积与空间层次。
- 衣饰与装备的重量可读，表面老化符合使用状态。
- 构图通过近远尺度、遮挡和节奏承载史诗感，近景也保持材料可信性。

## 可调整项

- 石构大厅、木构室内、乡村与开放地景均可承载本预设；不是每张都要宫殿。
- 色彩按材料、染织与气氛选择，土褐铁灰不是唯一色板。
- 规模、反差、洁净程度和仪式感按情境变化。

## 不应自动加入

- 默认骑士、王座、火炬、魔法或巨兽。
- 将所有中世纪材料都做成灰暗粗石，或把史诗理解为每张都用大全景。

## 风格锚点

EN：Photorealistic medieval-epic treatment, weighty and legible construction, differentiated stone, timber, metal, leather and textiles, credible material wear, motivated form-revealing light, scale relationships and layered framing that convey presence without losing physical plausibility.

中文：中世纪史诗摄影写实，厚重且可读的构造，清晰区分的石、木、金属、皮革与织物，可信的材料磨损，有来源的体积塑造光，以尺度关系和分层构图传达存在感，同时保持物理可信性。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

时代与地域细节服从用户世界；本卡只提供史诗写实表现，不代表所有结构已经完成历史核验。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
