# 55 · 都市超自然电影写实

- 分类：电影写实 / 都市超自然题材
- 媒介：现实环境中的真人电影感表达
- 类型：视觉预设
- 旧名称：奇幻超自然

## 核心特征

- 形态：现实比例和可信结构提供基线，不把全画面奇幻化。
- 材质：常见表面的粗糙度、反射和使用痕迹可信，异常按既定机制改变。
- 光影：现实光源建立基线，遮挡、逆光或明暗缺口制造不确定感，不强制黑夜。
- 色彩：克制环境色与少量异色形成张力，异色有视觉或剧情依据。
- 空间：框景、负空间、遮挡与视线控制信息暴露。

## 可调整项

日夜、室内外、冷暖、能见度与不安程度可变；雾、发光眼、月光蓝和烟紫仅在适合时采用。

## 不应自动加入

不自动加入吸血鬼、鬼魂、发光眼、恋爱或具体剧集人物；不混用作品名称替代视觉定义。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Grounded live-action supernatural cinematography, credible everyday forms and surfaces, motivated real-world lighting, restrained environmental colors with selective anomalous accents only where established, controlled concealment, purposeful negative space and coherent physical depth.

**中文：**立足现实的真人超自然电影摄影感，可信日常形体与表面，有动机的现实光照，克制环境色，仅在设定成立时加入选择性异常点缀，受控遮蔽，有目的的负空间与连贯物理纵深。

## 使用边界

异常内容由世界设定提供；本卡只控制其与现实基底的视觉关系。中英采用同一套特征，不分别引用不同剧集。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
