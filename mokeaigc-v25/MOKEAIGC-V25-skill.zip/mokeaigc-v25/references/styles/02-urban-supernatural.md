# 02 · 都市异能写实（暗黑悬疑）

- 分类：写实 / 都市悬疑
- 媒介：真人摄影观感
- 类型：视觉预设
- 旧名称：都市异能（暗黑，刑侦，悬疑）

## 核心特征

- 当代或既定时代的空间、器物与身体保持可辨认的现实质感。
- 异常感通过局部明暗、反射、空间遮挡或行为线索呈现，不以全画面特效替代。
- 暗部有层次，主体与背景用受控的轮廓或明度差分离。
- 构图保留未揭示的空间与信息，倾斜和偏置只在有叙事作用时使用。
- 已成立的能量效果与周围表面发生合理照明关系。

## 可调整项

- 暗蓝紫与电光青为可选夜景配色，白天或暖色室内沿用实际光源。
- 当代悬疑与未来霓虹分为内容条件；只有世界已设定未来科技时使用未来建筑和全息设备。
- 异常力量可隐而不显；能量光强度按剧情与画面尺度控制。

## 不应自动加入

- 默认未来城市、机械义体、全息广告、霓虹雨夜。
- 没有设定依据的发光眼睛、粒子光环或可见怪物。

## 风格锚点

EN：Photorealistic urban supernatural suspense, grounded material surfaces and credible spatial scale, controlled low-key illumination with readable shadows, selective visual anomalies, occlusion and negative space that preserve uncertainty, coherent interaction between any established light effect and surrounding surfaces.

中文：都市超自然悬疑写实，扎实的材料表面与可信的空间尺度，暗部可读的受控低调光照，选择性的视觉异常，以遮挡和负空间保留不确定性，既定发光效果与周围表面保持一致的照明互动。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

“异能”是题材条件，不能把未确立的超自然现象升级成世界事实。只迁移表现方式，不替换时代和城市。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
