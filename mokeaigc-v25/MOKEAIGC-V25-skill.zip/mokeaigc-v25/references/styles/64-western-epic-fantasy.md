# 64 · 西幻史诗电影写实

- 分类：电影写实 / 西方奇幻史诗
- 媒介：大尺度叙事中的真人电影感表达
- 类型：视觉预设
- 旧名称：西幻史诗

## 核心特征

- 形态：小细节与大体量有同一结构逻辑，宏大来自比例对照。
- 材质：自然与人工表面有工艺和环境痕迹，远近保持同一体系。
- 光影：环境光、地形遮挡与空气层次相互解释，不强制神性光束。
- 色彩：地域材料色组维持连续性，重点色有用途，不限大地色。
- 空间：近中远、遮挡和尺度参照建立深度，近景通过细节延续世界。

## 可调整项

距离、地形、天气、色调、光质与节奏可变；史诗不要求每张广角大场面或英雄姿势。

## 不应自动加入

不自动加入远征队、城邦、巨塔、战争、原作种族符号；不声称参考电影实际摄影器材。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Epic live-action fantasy cinematography, coherent relationships between intimate detail and large-scale forms, tactile differentiated materials, environmentally motivated light, a unified color system, layered atmospheric depth and purposeful scale references.

**中文：**史诗真人奇幻电影摄影感，亲密细节与大尺度形体的连贯关系，可触且区分明确的材质，有环境依据的光照，统一色彩体系，层叠空气纵深与有目的的尺度参照。

## 使用边界

史诗通过比例、环境关系和连续性实现，不只写成质量词或统一超广角；肖像与日常同样可以属于史诗世界。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
