# 16 · 中式恐怖写实

- 分类：写实 / 中式恐怖
- 媒介：真人摄影观感
- 类型：视觉预设
- 旧名称：中式恐怖

## 核心特征

- 熟悉空间与日常器物通过异常位置、遮挡或状态变化产生不安。
- 文化形制来自已经建立的生活或仪式背景，而非通用符号堆叠。
- 暗处与可见区域形成信息差，威胁可保留在画外。
- 材质的潮湿、干裂、腐朽或洁净程度符合地点和使用状况。
- 光源和颜色具有情境动机，冷暖冲突或局部色彩点可强化异常。

## 可调整项

- 旧宅民俗是可选子型，可用暗红/墨黑/枯黄；现代环境或日光恐怖可更换材料与色调。
- 光照可幽暗也可明亮，恐怖感仍需由空间和信息异常支撑。
- 超自然是否客观存在、是否可见，服从世界中的事实与未知边界。

## 不应自动加入

- 默认纸符、香烛、红灯笼、僵尸或腐朽老宅。
- 满画面霉斑、血迹、雾气，或把普通文化物件本身等同于恐怖。

## 风格锚点

EN：Photorealistic Chinese horror treatment, culturally grounded ordinary forms made unsettling through placement and visibility, precise material condition, motivated light, controlled concealment and off-frame uncertainty, tension between familiar structure and a small number of perceptible anomalies.

中文：中式恐怖摄影写实，具有文化生活依据的普通形制通过位置与可见性变得不安，准确的材料状态，有来源的光线，受控隐藏与画外不确定性，在熟悉结构和少量可感知异常之间形成张力。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

文化与仪式细节先服从已给设定；不要为了恐怖效果给所有画面追加民俗符号或改变事实/传闻的地位。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
