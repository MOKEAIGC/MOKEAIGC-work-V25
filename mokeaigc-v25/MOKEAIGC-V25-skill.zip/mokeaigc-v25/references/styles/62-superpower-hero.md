# 62 · 超能题材电影写实

- 分类：电影写实 / 超能题材
- 媒介：现实基底与设定一致的异常效果
- 类型：视觉预设
- 旧名称：超能异能

## 核心特征

- 形态：现实比例、重量和结构建立基线，变化由能力规则决定。
- 材质：表面差异真实，异常与表面的交互符合机制。
- 光影：真实光源提供基线，只有发光能力才产生相应反射与补光。
- 色彩：效果色来自既定能力设计，不统一电蓝或绯红。
- 空间：受力、距离、遮挡或反应表现作用范围，不可见能力可用视线与反应表达。

## 可调整项

先继承能力机制，再调整可见性、规模、明暗、冷暖、机位与动作强度。

## 不应自动加入

不自动加入发光眼、能量束、爆炸、觉醒、都市对决或英雄身份；感知、隐形、心灵和力量不必发光。

## 风格锚点

以下用于与主体、场景及构图组合，不是最终提示词。

**EN:** Grounded live-action superpower imagery, credible anatomy and scale, differentiated real-world surfaces, motivated environmental lighting, coherent interaction of any established visible effects with surrounding materials, controlled emphasis and readable cause-and-response relationships.

**中文：**立足现实的真人超能视觉，可信解剖与尺度，可区分现实表面，有动机的环境照明，仅当设定存在可见效果时保持它与周围材质的连贯交互，受控视觉重点与可读因果反应关系。

## 使用边界

此卡不定义能力；不可见能力的动作、物体位移或环境反应也须得到世界设定支持。

执行 [V25主入口](../../SKILL.md) 的选择、跳过与媒介适配规则；用户要求和既定世界事实优先。
