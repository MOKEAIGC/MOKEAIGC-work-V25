# 05 · 赛博武侠写实

- 分类：写实 / 科幻融合
- 媒介：真人摄影与可信合成观感
- 类型：视觉预设
- 旧名称：赛博武侠

## 核心特征

- 传统轮廓与机械/电子结构在连接、支撑和使用方式上形成完整关系。
- 织物、旧木、石材、合金与发光组件保留不同粗糙度与反射方式。
- 局部人工发光映照实际表面，亮度和光晕不掩盖主体结构。
- 身体与装备的重量和关节关系可信，装饰不能妨碍已有行动逻辑。
- 构图保留东方形制的线条节奏，同时让技术构造可读。

## 可调整项

- 品红/电光青/金色是可选霓虹子预设，也可采用日光、低彩色或单色人工光。
- 武侠与科技的占比由世界决定；既定物件可通过材料与构造融合表达。
- 天气、都市密度、发光剑气均按用户设定出现。

## 不应自动加入

- 默认雨夜、高楼、全息广告、机械肢体。
- 把无功能关系的飞檐、齿轮、符文堆在同一物件上。

## 风格锚点

EN：Photorealistic cyber-wuxia treatment, integrated traditional silhouettes and functional technological construction, differentiated organic and engineered materials, controlled emissive accents with coherent surface reflections, grounded articulation and weight, rhythmic lines with readable structural detail.

中文：赛博武侠摄影写实，传统轮廓与功能性技术构造融为整体，有机材料与工业材料清晰区分，受控的发光点缀与一致的表面反射，可信的关节和重量，有节奏的线条与可读的结构细节。

锚点仅用于组合具体提示词，不是完整的最终图像提示词。

## 使用边界

原库“历史正剧”分类不适用于这一科幻融合预设。保持用户已给的江湖与技术规则；不能仅用霓虹替代融合设计。 按[主技能](../../SKILL.md)组合当前已确定的主体、世界、交付类型与用户覆盖项。
